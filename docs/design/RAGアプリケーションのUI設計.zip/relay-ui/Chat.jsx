import React from "react";
import { colors, font, radius, fileTypeStyle, useHover, useKeyframes } from "./tokens.js";

/**
 * チャットの吹き出し。user は右寄せ淡インディゴ、assistant は左寄せカード。
 * @param {object} props
 * @param {'user'|'assistant'} props.role
 * @param {React.ReactNode} props.children  本文（<sup> での引用番号埋め込み可）
 * @param {React.ReactNode} [props.footer]  assistant の本文下に出すノード（出典・操作など）
 */
export function MessageBubble({ role, children, footer }) {
  if (role === "user") {
    return (
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <div style={{ maxWidth: "78%", background: colors.accent.soft, color: colors.gray[800], borderRadius: "14px 14px 4px 14px", padding: "12px 16px", fontFamily: font.sans, fontSize: 14.5, lineHeight: 1.6 }}>
          {children}
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
      <Avatar />
      <div style={{ maxWidth: "82%", minWidth: 0 }}>
        <div style={{ background: "#fff", border: `1px solid ${colors.gray[200]}`, borderRadius: "4px 14px 14px 14px", padding: "14px 18px", fontFamily: font.sans, fontSize: 14.5, lineHeight: 1.75, color: colors.gray[800] }}>
          {children}
        </div>
        {footer && <div style={{ marginTop: 9 }}>{footer}</div>}
      </div>
    </div>
  );
}

export function Avatar({ size = 30 }) {
  return (
    <div style={{ width: size, height: size, flex: "none", borderRadius: radius.md, background: colors.gray[900], color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font.sans, fontWeight: 700, fontSize: size * 0.43 }}>
      R
    </div>
  );
}

/** 本文中の上付き引用番号。 */
export function Citation({ n, onClick }) {
  return (
    <sup onClick={onClick} style={{ color: colors.accent[500], fontWeight: 700, fontFamily: font.mono, fontSize: 11, cursor: "pointer" }}>{n}</sup>
  );
}

/** コンパクトな引用チップ（出典名 + 番号）。 */
export function CitationChip({ n, label, onClick }) {
  const [hover, hoverProps] = useHover();
  return (
    <span {...hoverProps} onClick={onClick} style={{
      display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
      border: `1px solid ${hover ? colors.accent[200] : colors.gray[200]}`,
      background: hover ? "#fafbff" : "#fff", borderRadius: 7, padding: "4px 10px",
      fontFamily: font.sans, fontSize: 12.5, transition: "all .12s",
    }}>
      <span style={{ width: 15, height: 15, borderRadius: 4, background: colors.accent[500], color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontFamily: font.mono, fontWeight: 700, fontSize: 9 }}>{n}</span>
      {label}
    </span>
  );
}

/**
 * 引用ソースカード（RAG の根拠提示の中核）。
 * @param {object} props
 * @param {number} props.index               引用番号
 * @param {'PDF'|'DOC'|'XLS'|'TXT'} props.fileType
 * @param {string} props.title               出典ファイル名
 * @param {string} props.snippet             該当箇所の抜粋
 * @param {number} props.relevance           関連度 0..1
 * @param {string} [props.meta]              ページ・条項など
 * @param {() => void} [props.onOpen]
 */
export function SourceCard({ index, fileType = "PDF", title, snippet, relevance = 0, meta, onOpen }) {
  const [hover, hoverProps] = useHover();
  const ft = fileTypeStyle[fileType] || fileTypeStyle.TXT;
  return (
    <div {...hoverProps} onClick={onOpen} style={{
      border: `1px solid ${hover ? colors.accent[200] : colors.gray[200]}`,
      background: hover ? "#fafbff" : "#fff", borderRadius: radius.xl, padding: 16,
      display: "flex", gap: 14, cursor: "pointer", transition: "all .12s",
    }}>
      <div style={{ width: 34, height: 34, flex: "none", borderRadius: radius.md, background: ft.bg, color: ft.fg, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font.mono, fontWeight: 700, fontSize: 11 }}>{fileType}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <span style={{ width: 18, height: 18, flex: "none", borderRadius: 5, background: colors.accent[500], color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font.mono, fontWeight: 700, fontSize: 10 }}>{index}</span>
          <span style={{ fontFamily: font.sans, fontSize: 14, fontWeight: 700, color: colors.gray[900] }}>{title}</span>
        </div>
        <div style={{ fontFamily: font.sans, fontSize: 13, lineHeight: 1.6, color: colors.gray[700], background: "#f8f8fb", borderLeft: `2px solid ${colors.accent[200]}`, borderRadius: "0 6px 6px 0", padding: "8px 12px", marginBottom: 9 }}>
          「{snippet}」
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, fontFamily: font.mono, fontWeight: 500, fontSize: 11, color: colors.gray[500] }}>
          {meta && <span>{meta}</span>}
          <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
            関連度
            <span style={{ width: 54, height: 5, background: colors.gray[200], borderRadius: 3, overflow: "hidden", display: "inline-block" }}>
              <span style={{ display: "block", width: `${Math.round(relevance * 100)}%`, height: "100%", background: colors.success.dot }} />
            </span>
            {relevance.toFixed(2)}
          </span>
          <span style={{ marginLeft: "auto", color: colors.accent[500] }}>原典を開く →</span>
        </div>
      </div>
    </div>
  );
}

/**
 * 回答の信頼度インジケータ。score から高/中/低を自動判定し 5 分割バーで表示。
 * @param {object} props
 * @param {number} props.score   0..1
 * @param {boolean}[props.compact]  バッジ1個のコンパクト表示
 */
export function ConfidenceIndicator({ score = 0, compact, note }) {
  const pct = Math.round(score * 100);
  const level = score >= 0.75 ? "high" : score >= 0.45 ? "med" : "low";
  const map = {
    high: { label: "信頼度 高", c: colors.success },
    med:  { label: "信頼度 中", c: colors.warning },
    low:  { label: "信頼度 低", c: colors.danger },
  }[level];
  const filled = Math.max(1, Math.round(score * 5));

  if (compact) {
    return (
      <span style={{ display: "inline-flex", alignItems: "center", gap: 7, background: map.c.bg, color: map.c.fg, borderRadius: 999, padding: "3px 9px", fontFamily: font.sans, fontSize: 11, fontWeight: 700 }}>
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: map.c.dot }} />
        {map.label} {pct}%
      </span>
    );
  }
  return (
    <div style={{ background: "#fff", border: `1px solid ${colors.gray[200]}`, borderRadius: radius.xl, padding: 18 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontFamily: font.sans, fontSize: 13, fontWeight: 700, color: map.c.fg }}>
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: map.c.dot }} />{map.label}
        </span>
        <span style={{ fontFamily: font.mono, fontWeight: 600, fontSize: 13, color: map.c.fg }}>{pct}%</span>
      </div>
      <div style={{ display: "flex", gap: 4, marginBottom: note ? 10 : 0 }}>
        {[0, 1, 2, 3, 4].map((i) => (
          <span key={i} style={{ flex: 1, height: 6, borderRadius: 3, background: i < filled ? map.c.dot : map.c.track }} />
        ))}
      </div>
      {note && <div style={{ fontFamily: font.sans, fontSize: 12, lineHeight: 1.5, color: colors.gray[600] }}>{note}</div>}
    </div>
  );
}

/** 根拠不足の注意バナー。 */
export function GroundingWarning({ children }) {
  return (
    <div style={{ background: "#fdf6ec", border: "1px solid #f2dcb3", borderRadius: radius.xl, padding: "14px 18px", display: "flex", gap: 12, alignItems: "flex-start" }}>
      <span style={{ fontSize: 16, lineHeight: 1.4 }}>⚠</span>
      <div style={{ fontFamily: font.sans, fontSize: 13, lineHeight: 1.6, color: "#7a5a13" }}>{children}</div>
    </div>
  );
}

/**
 * ストリーミング中のテキスト。streaming=true の間は点滅カーソルを表示。
 * @param {object} props
 * @param {string} props.text
 * @param {boolean}[props.streaming=true]
 */
export function StreamingText({ text, streaming = true }) {
  useKeyframes();
  return (
    <span>
      {text}
      {streaming && (
        <span style={{ display: "inline-block", width: 8, height: 17, background: colors.accent[500], borderRadius: 1, verticalAlign: -3, marginLeft: 2, animation: "relay-blink 1s step-end infinite" }} />
      )}
    </span>
  );
}

/** 「考え中」のドットアニメーション。 */
export function TypingDots() {
  useKeyframes();
  return (
    <div style={{ display: "inline-flex", gap: 5, background: "#fff", border: `1px solid ${colors.gray[200]}`, borderRadius: radius.xl, padding: "14px 18px" }}>
      {[0, 0.2, 0.4].map((d, i) => (
        <span key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: colors.gray[400], animation: `relay-dot 1.2s ${d}s infinite` }} />
      ))}
    </div>
  );
}

/** 回転スピナー。 */
export function Spinner({ size = 16 }) {
  useKeyframes();
  return <span style={{ display: "inline-block", width: size, height: size, borderRadius: "50%", border: `2px solid ${colors.accent[200]}`, borderTopColor: colors.accent[500], animation: "relay-spin .7s linear infinite" }} />;
}
