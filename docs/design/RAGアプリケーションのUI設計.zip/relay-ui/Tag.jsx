import React from "react";
import { colors, font, radius } from "./tokens.js";

/** カテゴリ等の中立タグ。removable で ✕ を表示。 */
export function Tag({ children, accent, removable, onRemove, style }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      background: accent ? colors.accent.soft : colors.gray[100],
      color: accent ? colors.accent[600] : colors.gray[700],
      borderRadius: radius.sm, padding: removable ? "4px 8px 4px 10px" : "4px 10px",
      fontFamily: font.sans, fontSize: 12.5, fontWeight: 500, ...style,
    }}>
      {children}
      {removable && (
        <span onClick={onRemove} style={{ cursor: "pointer", color: accent ? colors.accent[400] : colors.gray[500] }}>✕</span>
      )}
    </span>
  );
}

const STATUS = {
  done:       { label: "処理済", c: colors.success },
  processing: { label: "処理中", c: colors.warning },
  error:      { label: "エラー", c: colors.danger },
  idle:       { label: "未処理", c: { fg: colors.gray[600], bg: colors.gray[100], dot: colors.gray[400] } },
};

/**
 * ドット付きステータスバッジ。
 * @param {object} props
 * @param {'done'|'processing'|'error'|'idle'} props.status
 * @param {boolean} [props.pulse]  ドットを点滅（処理中向け）
 */
export function StatusBadge({ status = "idle", pulse, style }) {
  const s = STATUS[status] || STATUS.idle;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6, width: "fit-content",
      background: s.c.bg, color: s.c.fg, borderRadius: radius.pill,
      padding: "4px 11px", fontFamily: font.sans, fontSize: 12, fontWeight: 500, ...style,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.c.dot, animation: pulse ? "relay-shimmer 1.4s infinite" : undefined }} />
      {s.label}
    </span>
  );
}

/** カウントバッジ。accent でインディゴ塗り。 */
export function CountBadge({ children, accent, style }) {
  return (
    <span style={{
      background: accent ? colors.accent[500] : colors.gray[100],
      color: accent ? "#fff" : colors.gray[600], borderRadius: 10, padding: "1px 7px",
      fontFamily: font.mono, fontWeight: 600, fontSize: 11, ...style,
    }}>
      {children}
    </span>
  );
}
