import React from "react";
import { colors, font, radius, fileTypeStyle, useHover } from "./tokens.js";
import { StatusBadge } from "./Tag.jsx";
import { Spinner as ChatSpinner } from "./Chat.jsx";

/**
 * ドキュメント1行（リスト用）。grid 列は親 DocumentList が定義。
 * @param {object} props
 * @param {'PDF'|'DOC'|'XLS'|'TXT'} props.fileType
 * @param {string} props.name
 * @param {string} [props.meta]    サイズ・部署など
 * @param {'done'|'processing'|'error'|'idle'} props.status
 * @param {string} props.date
 * @param {() => void} [props.onMenu]
 */
export function DocumentRow({ fileType = "PDF", name, meta, status = "done", date, onMenu }) {
  const [hover, hoverProps] = useHover();
  const ft = fileTypeStyle[fileType] || fileTypeStyle.TXT;
  return (
    <div {...hoverProps} style={{
      display: "grid", gridTemplateColumns: "1fr 130px 130px 40px", gap: 16,
      padding: "14px 18px", alignItems: "center",
      borderBottom: `1px solid ${colors.gray[100]}`, background: hover ? "#fafbff" : "transparent",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
        <span style={{ width: 30, height: 30, flex: "none", borderRadius: 7, background: ft.bg, color: ft.fg, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font.mono, fontWeight: 700, fontSize: 10 }}>{fileType}</span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontFamily: font.sans, fontSize: 14, fontWeight: 500, color: colors.gray[900], whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
          {meta && <div style={{ fontFamily: font.mono, fontWeight: 500, fontSize: 11, color: colors.gray[400], marginTop: 2 }}>{meta}</div>}
        </div>
      </div>
      <StatusBadge status={status} pulse={status === "processing"} />
      <span style={{ fontFamily: font.mono, fontWeight: 500, fontSize: 12, color: colors.gray[600] }}>{date}</span>
      <span onClick={onMenu} style={{ color: colors.gray[400], cursor: "pointer", textAlign: "center" }}>⋯</span>
    </div>
  );
}

/**
 * ヘッダ付きドキュメントリスト。
 * @param {object} props
 * @param {Array} props.items  DocumentRow に渡す props の配列（key 用に id 推奨）
 */
export function DocumentList({ items = [] }) {
  return (
    <div style={{ background: "#fff", border: `1px solid ${colors.gray[200]}`, borderRadius: radius.xl, overflow: "hidden" }}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 130px 130px 40px", gap: 16, padding: "11px 18px", background: colors.gray[50], borderBottom: `1px solid ${colors.gray[200]}`, fontFamily: font.mono, fontWeight: 600, fontSize: 11, color: colors.gray[500], textTransform: "uppercase", letterSpacing: ".04em" }}>
        <span>ドキュメント</span><span>ステータス</span><span>更新日</span><span />
      </div>
      {items.map((it, i) => <DocumentRow key={it.id ?? i} {...it} />)}
    </div>
  );
}

/** ドラッグ&ドロップのアップロード領域。 */
export function UploadDropzone({ accept = "PDF · DOCX · XLSX · TXT（最大50MB）", onSelect }) {
  const [hover, hoverProps] = useHover();
  return (
    <div {...hoverProps} onClick={onSelect} style={{
      border: `1.5px dashed ${hover ? colors.accent[400] : colors.accent[200]}`,
      background: hover ? "#f4f4fd" : "#fafbff", borderRadius: radius.xl,
      padding: "36px 24px", display: "flex", flexDirection: "column", alignItems: "center",
      textAlign: "center", cursor: "pointer", transition: "all .12s",
    }}>
      <div style={{ width: 46, height: 46, borderRadius: 12, background: colors.accent.soft, color: colors.accent[500], display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, marginBottom: 14 }}>↑</div>
      <div style={{ fontFamily: font.sans, fontSize: 15, fontWeight: 700, color: colors.gray[900], marginBottom: 5 }}>ファイルをドロップ</div>
      <div style={{ fontFamily: font.sans, fontSize: 12.5, color: colors.gray[600], lineHeight: 1.5 }}>またはクリックして選択<br />{accept}</div>
    </div>
  );
}

/**
 * 取り込み（ベクトル化）進捗バー。
 * @param {object} props
 * @param {string} props.name
 * @param {number} [props.progress]  0..100。null/undefined で「待機中」
 * @param {string} [props.note]
 */
export function IngestProgress({ name, progress, note }) {
  const waiting = progress == null;
  const done = progress === 100;
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 7 }}>
        <span style={{ fontFamily: font.sans, fontSize: 13, color: waiting ? colors.gray[600] : colors.gray[800], whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</span>
        <span style={{ fontFamily: font.mono, fontWeight: 600, fontSize: 11, color: waiting ? colors.gray[400] : colors.accent[500], flex: "none", marginLeft: 8 }}>{waiting ? "待機中" : `${progress}%`}</span>
      </div>
      <div style={{ height: 6, background: waiting ? colors.gray[100] : colors.accent.soft, borderRadius: 3, overflow: "hidden" }}>
        <span style={{ display: "block", width: `${waiting ? 0 : progress}%`, height: "100%", background: waiting ? colors.gray[400] : colors.accent[500], borderRadius: 3 }} />
      </div>
      {note && !waiting && !done && <div style={{ fontFamily: font.mono, fontWeight: 500, fontSize: 11, color: colors.gray[400], marginTop: 6 }}>{note}</div>}
    </div>
  );
}

const PIPELINE = ["アップロード", "テキスト抽出", "埋め込み生成", "インデックス", "検索可能"];

/**
 * 取り込みパイプラインのステッパー。current 番目を処理中として表示。
 * @param {object} props
 * @param {number} props.current  0-indexed の現在ステップ
 * @param {string[]} [props.steps]
 */
export function ProcessingStatus({ current = 2, steps = PIPELINE }) {
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      {steps.map((label, i) => {
        const done = i < current, active = i === current;
        const circle = done
          ? { background: colors.success.bg, color: colors.success.dot, border: `2px solid ${colors.success.dot}` }
          : active
          ? { background: colors.accent.soft, color: colors.accent[500], border: `2px solid ${colors.accent[500]}` }
          : { background: colors.gray[100], color: colors.gray[400], border: `2px solid ${colors.gray[200]}` };
        return (
          <React.Fragment key={i}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, flex: "none" }}>
              <span style={{ width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, ...circle }}>
                {done ? "✓" : active ? <ChatSpinner size={13} /> : i + 1}
              </span>
              <span style={{ fontFamily: font.sans, fontSize: 11.5, fontWeight: active ? 700 : 500, color: active ? colors.accent[500] : done ? colors.gray[900] : colors.gray[400] }}>{label}</span>
            </div>
            {i < steps.length - 1 && (
              <div style={{ flex: 1, height: 2, margin: "0 6px 22px", background: i < current ? (i + 1 <= current ? colors.success.dot : colors.accent[500]) : colors.gray[200] }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}
