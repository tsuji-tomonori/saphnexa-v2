import React from "react";
import { colors, font, radius, useFocus } from "./tokens.js";

/**
 * 大きめ検索バー。ハイブリッド/キーワードのモード切替トグル付き。
 * @param {object} props
 * @param {string} [props.value]
 * @param {(v:string)=>void} [props.onChange]
 * @param {'hybrid'|'keyword'} [props.mode='hybrid']
 * @param {(m:string)=>void} [props.onModeChange]
 */
export function SearchBar({ value, onChange, mode = "hybrid", onModeChange, placeholder = "社内ナレッジを検索…" }) {
  const [focus, focusProps] = useFocus();
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10, background: "#fff",
      border: `1px solid ${focus ? colors.accent[500] : colors.gray[300]}`,
      boxShadow: focus ? `0 0 0 3px ${colors.accent.soft}` : "none",
      borderRadius: radius.lg, padding: "13px 16px", transition: "border-color .12s, box-shadow .12s",
    }}>
      <span style={{ color: colors.gray[500], fontSize: 16 }}>⌕</span>
      <input
        value={value} onChange={(e) => onChange && onChange(e.target.value)} placeholder={placeholder}
        {...focusProps}
        style={{ flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent", fontFamily: font.sans, fontSize: 15 }}
      />
      <ModeToggle mode={mode} onModeChange={onModeChange} />
    </div>
  );
}

function ModeToggle({ mode, onModeChange }) {
  const opt = (key, label) => {
    const on = mode === key;
    return (
      <span
        onClick={() => onModeChange && onModeChange(key)}
        style={{
          fontFamily: font.sans, fontSize: 11.5, fontWeight: 500, cursor: "pointer",
          padding: "4px 9px", borderRadius: 5,
          color: on ? colors.gray[900] : colors.gray[500],
          background: on ? "#fff" : "transparent",
          boxShadow: on ? "0 1px 2px rgba(0,0,0,.06)" : "none",
        }}
      >{label}</span>
    );
  };
  return (
    <div style={{ display: "flex", background: colors.gray[100], borderRadius: 7, padding: 2, flex: "none" }}>
      {opt("hybrid", "ハイブリッド")}
      {opt("keyword", "キーワード")}
    </div>
  );
}

/** ドロップダウン起点となるフィルターボタン（▾付き）。 */
export function FilterButton({ children, onClick }) {
  const [hover, setHover] = React.useState(false);
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
        border: `1px solid ${hover ? colors.gray[400] : colors.gray[300]}`,
        background: hover ? colors.gray[50] : "#fff", borderRadius: radius.md,
        padding: "6px 11px", fontFamily: font.sans, fontSize: 12.5, color: colors.gray[700],
      }}
    >
      {children} <span style={{ color: colors.gray[500] }}>▾</span>
    </span>
  );
}

/** 適用中フィルターチップ（✕で解除）。 */
export function FilterChip({ children, onRemove }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, background: colors.accent.soft, color: colors.accent[600], borderRadius: 7, padding: "4px 8px 4px 10px", fontFamily: font.sans, fontSize: 12, fontWeight: 500 }}>
      {children}<span onClick={onRemove} style={{ cursor: "pointer" }}>✕</span>
    </span>
  );
}

/**
 * 検索結果カード。snippet 内の {mark:"..."} 部分をハイライト表示。
 * @param {object} props
 * @param {'PDF'|'DOC'|'XLS'|'TXT'} props.fileType
 * @param {string} props.title
 * @param {Array<string|{mark:string}>} props.snippet  文字列とハイライト指定の配列
 * @param {number} props.relevance  0..1
 * @param {string} [props.meta]
 */
export function SearchResultCard({ fileType = "PDF", title, snippet = [], relevance = 0, meta, onClick }) {
  const [hover, setHover] = React.useState(false);
  const ft = { PDF: { bg: "#fdece8", fg: "#b23e2e" }, DOC: { bg: "#e9f1fb", fg: "#2d6fb8" }, XLS: { bg: "#e9f6ee", fg: "#1f7d4d" }, TXT: { bg: "#f4f5f7", fg: "#8b8e98" } }[fileType];
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ border: `1px solid ${hover ? colors.accent[200] : colors.gray[200]}`, background: hover ? "#fafbff" : "#fff", borderRadius: 11, padding: 15, cursor: "pointer", transition: "all .12s" }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 8 }}>
        <span style={{ width: 24, height: 24, borderRadius: 6, background: ft.bg, color: ft.fg, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font.mono, fontWeight: 700, fontSize: 9 }}>{fileType}</span>
        <span style={{ fontFamily: font.sans, fontSize: 14, fontWeight: 700, color: colors.gray[900] }}>{title}</span>
        <span style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6, fontFamily: font.mono, fontWeight: 500, fontSize: 11, color: colors.success.fg }}>
          {relevance.toFixed(2)}
          <span style={{ width: 46, height: 5, background: colors.gray[200], borderRadius: 3, overflow: "hidden", display: "inline-block" }}>
            <span style={{ display: "block", width: `${Math.round(relevance * 100)}%`, height: "100%", background: colors.success.dot }} />
          </span>
        </span>
      </div>
      <div style={{ fontFamily: font.sans, fontSize: 13, lineHeight: 1.65, color: colors.gray[700] }}>
        {snippet.map((part, i) =>
          typeof part === "string"
            ? <React.Fragment key={i}>{part}</React.Fragment>
            : <mark key={i} style={{ background: colors.highlight, color: colors.gray[900], borderRadius: 2, padding: "0 2px" }}>{part.mark}</mark>
        )}
      </div>
      {meta && <div style={{ fontFamily: font.mono, fontWeight: 500, fontSize: 11, color: colors.gray[400], marginTop: 8 }}>{meta}</div>}
    </div>
  );
}
