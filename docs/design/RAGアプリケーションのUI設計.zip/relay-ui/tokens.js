/**
 * Relay DS — design tokens & shared hooks
 * 社内ナレッジ検索 RAG UI のための基礎トークン。
 * すべてのコンポーネントはここを単一の真実として参照します。
 */
import { useState, useEffect } from "react";

export const colors = {
  gray: {
    50: "#fafbfc", 100: "#f4f5f7", 200: "#e9eaee", 300: "#d8dadf",
    400: "#b4b7bf", 500: "#8b8e98", 600: "#62656e", 700: "#44464d",
    800: "#2a2c31", 900: "#16171a",
  },
  accent: { soft: "#eeeefb", 200: "#c7c7f5", 400: "#8f8fea", 500: "#5b5bd6", 600: "#4646b8" },
  success: { fg: "#1f7d4d", bg: "#e9f6ee", dot: "#2f9e64", track: "#cfe9da" },
  warning: { fg: "#9a6a13", bg: "#fbf3e3", dot: "#c98a1a", track: "#f0e0c0" },
  danger:  { fg: "#b23e2e", bg: "#fdece8", dot: "#d4503e", track: "#f0cabf" },
  highlight: "#fff3cf",
};

export const font = {
  sans: "'Zen Kaku Gothic New', system-ui, sans-serif",
  mono: "'JetBrains Mono', ui-monospace, monospace",
};

/** 4px ベーススケール */
export const space = { "2xs": 4, xs: 8, sm: 12, md: 16, lg: 24, xl: 32, "2xl": 48 };

export const radius = { sm: 6, md: 8, lg: 10, xl: 14, pill: 999 };

export const shadow = {
  sm: "0 1px 2px rgba(22,23,26,.06), 0 1px 3px rgba(22,23,26,.04)",
  md: "0 4px 12px rgba(22,23,26,.08), 0 2px 4px rgba(22,23,26,.04)",
  lg: "0 12px 32px rgba(22,23,26,.12), 0 4px 8px rgba(22,23,26,.06)",
};

/** ファイル種別 → バッジ配色 */
export const fileTypeStyle = {
  PDF: { bg: "#fdece8", fg: "#b23e2e" },
  DOC: { bg: "#e9f1fb", fg: "#2d6fb8" },
  XLS: { bg: "#e9f6ee", fg: "#1f7d4d" },
  TXT: { bg: "#f4f5f7", fg: "#8b8e98" },
};

/* ---------- hooks ---------- */

/** ホバー状態を返す: const [hover, hoverProps] = useHover(); */
export function useHover() {
  const [hover, setHover] = useState(false);
  return [hover, { onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false) }];
}

/** フォーカス状態を返す: const [focus, focusProps] = useFocus(); */
export function useFocus() {
  const [focus, setFocus] = useState(false);
  return [focus, { onFocus: () => setFocus(true), onBlur: () => setFocus(false) }];
}

/** blink / dot / spin / shimmer の @keyframes を一度だけ document に注入 */
export function ensureKeyframes() {
  if (typeof document === "undefined" || document.getElementById("relay-kf")) return;
  const s = document.createElement("style");
  s.id = "relay-kf";
  s.textContent =
    "@keyframes relay-blink{0%,49%{opacity:1}50%,100%{opacity:0}}" +
    "@keyframes relay-dot{0%,80%,100%{transform:translateY(0);opacity:.4}40%{transform:translateY(-4px);opacity:1}}" +
    "@keyframes relay-spin{to{transform:rotate(360deg)}}" +
    "@keyframes relay-shimmer{0%{opacity:.35}50%{opacity:1}100%{opacity:.35}}";
  document.head.appendChild(s);
}

/** マウント時に keyframes を保証する hook */
export function useKeyframes() {
  useEffect(() => { ensureKeyframes(); }, []);
}
