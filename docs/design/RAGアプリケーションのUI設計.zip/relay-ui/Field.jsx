import React from "react";
import { colors, font, radius, useFocus } from "./tokens.js";

const ringStyle = (focus, error) => ({
  borderColor: error ? colors.danger.dot : focus ? colors.accent[500] : colors.gray[300],
  boxShadow: focus ? `0 0 0 3px ${error ? "#fdece8" : colors.accent.soft}` : "none",
});

function Label({ children, error }) {
  if (!children) return null;
  return (
    <label style={{ display: "block", fontFamily: font.sans, fontSize: 12.5, fontWeight: 500, color: error ? colors.danger.fg : colors.gray[700], marginBottom: 7 }}>
      {children}
    </label>
  );
}

/**
 * 単一行テキスト入力。
 * @param {object} props
 * @param {string} [props.label]
 * @param {string} [props.error]   エラーメッセージ（指定で赤表示）
 */
export function TextField({ label, error, style, ...rest }) {
  const [focus, focusProps] = useFocus();
  return (
    <div>
      <Label error={!!error}>{label}</Label>
      <input
        {...focusProps} {...rest}
        style={{
          width: "100%", boxSizing: "border-box", border: "1px solid", borderRadius: radius.md,
          padding: "10px 12px", fontFamily: font.sans, fontSize: 14, color: colors.gray[900],
          outline: "none", transition: "border-color .12s, box-shadow .12s",
          ...ringStyle(focus, !!error), ...style,
        }}
      />
      {error && <div style={{ fontFamily: font.sans, fontSize: 12, color: colors.danger.fg, marginTop: 6 }}>{error}</div>}
    </div>
  );
}

/** 複数行入力 */
export function TextArea({ label, error, rows = 3, style, ...rest }) {
  const [focus, focusProps] = useFocus();
  return (
    <div>
      <Label error={!!error}>{label}</Label>
      <textarea
        rows={rows} {...focusProps} {...rest}
        style={{
          width: "100%", boxSizing: "border-box", border: "1px solid", borderRadius: radius.md,
          padding: "10px 12px", fontFamily: font.sans, fontSize: 14, color: colors.gray[900],
          outline: "none", resize: "none", minHeight: 78, transition: "border-color .12s, box-shadow .12s",
          ...ringStyle(focus, !!error), ...style,
        }}
      />
    </div>
  );
}

/**
 * アイコン付き検索フィールド。
 * @param {object} props
 * @param {string} [props.shortcut]  右端に出すショートカット表示（例 "⌘K"）
 * @param {React.ReactNode} [props.trailing]  右端の任意ノード（shortcut より優先）
 */
export function SearchField({ shortcut, trailing, style, ...rest }) {
  const [focus, focusProps] = useFocus();
  return (
    <div
      style={{
        display: "flex", alignItems: "center", gap: 8, background: "#fff",
        border: "1px solid", borderRadius: radius.md, padding: "10px 12px",
        transition: "border-color .12s, box-shadow .12s", ...ringStyle(focus, false), ...style,
      }}
    >
      <span style={{ color: colors.gray[500], fontSize: 14 }}>⌕</span>
      <input
        {...focusProps} {...rest}
        style={{ flex: 1, minWidth: 0, border: "none", outline: "none", background: "transparent", fontFamily: font.sans, fontSize: 14 }}
      />
      {trailing}
      {!trailing && shortcut && (
        <span style={{ fontFamily: font.mono, fontWeight: 500, fontSize: 10, color: colors.gray[400], border: `1px solid ${colors.gray[200]}`, borderRadius: 4, padding: "2px 5px" }}>
          {shortcut}
        </span>
      )}
    </div>
  );
}
