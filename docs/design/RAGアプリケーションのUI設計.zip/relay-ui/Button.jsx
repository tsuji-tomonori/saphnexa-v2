import React from "react";
import { colors, font, radius, useHover } from "./tokens.js";

const SIZES = {
  sm: { padding: "5px 12px", fontSize: 12, radius: radius.sm },
  md: { padding: "9px 18px", fontSize: 14, radius: radius.md },
  lg: { padding: "13px 24px", fontSize: 15, radius: radius.lg },
};

/**
 * @typedef {'primary'|'secondary'|'ghost'|'danger'} ButtonVariant
 * @param {object}        props
 * @param {ButtonVariant} [props.variant='primary']
 * @param {'sm'|'md'|'lg'}[props.size='md']
 * @param {React.ReactNode}[props.icon]    先頭アイコン（文字 or ノード）
 * @param {boolean}       [props.disabled]
 * @param {React.ReactNode} props.children
 */
export function Button({ variant = "primary", size = "md", icon, disabled, children, style, ...rest }) {
  const [hover, hoverProps] = useHover();
  const s = SIZES[size] || SIZES.md;

  const variants = {
    primary:   { background: hover ? colors.accent[600] : colors.accent[500], color: "#fff", border: "none" },
    secondary: { background: hover ? colors.gray[100] : "#fff", color: colors.gray[800], border: `1px solid ${hover ? colors.gray[400] : colors.gray[300]}` },
    ghost:     { background: hover ? colors.gray[100] : "transparent", color: colors.gray[700], border: "none" },
    danger:    { background: hover ? "#fdf3f1" : "#fff", color: colors.danger.fg, border: "1px solid #f0c9c3" },
  };
  const v = disabled
    ? { background: colors.gray[200], color: colors.gray[400], border: "none", cursor: "not-allowed" }
    : { ...variants[variant], cursor: "pointer" };

  return (
    <button
      {...(disabled ? {} : hoverProps)}
      {...rest}
      disabled={disabled}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
        fontFamily: font.sans, fontWeight: 500, fontSize: s.fontSize, lineHeight: 1.2,
        padding: s.padding, borderRadius: s.radius, whiteSpace: "nowrap",
        transition: "background .12s, border-color .12s", ...v, ...style,
      }}
    >
      {icon != null && <span style={{ fontSize: s.fontSize + 1, lineHeight: 1 }}>{icon}</span>}
      {children}
    </button>
  );
}

/** アイコンのみの正方ボタン */
export function IconButton({ children, size = 38, style, ...rest }) {
  const [hover, hoverProps] = useHover();
  return (
    <button
      {...hoverProps} {...rest}
      style={{
        width: size, height: size, display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: hover ? colors.gray[100] : "#fff", color: colors.gray[700],
        border: `1px solid ${colors.gray[300]}`, borderRadius: radius.md, cursor: "pointer",
        fontSize: 16, transition: "background .12s", ...style,
      }}
    >
      {children}
    </button>
  );
}
