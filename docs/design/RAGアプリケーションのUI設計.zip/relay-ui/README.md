# Relay DS — React コンポーネント

社内ナレッジ検索 RAG アプリ向けの React UI ライブラリ。クリーン/ミニマル、ニュートラル基調。
すべて**依存ゼロ**（React のみ）・**インラインスタイル**で実装しており、そのままコードベースに取り込めます。

## セットアップ

1. `relay-ui/` をプロジェクトに配置。
2. フォントを読み込む（`<head>` か CSS）:

```html
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Zen+Kaku+Gothic+New:wght@400;500;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

3. インポート:

```jsx
import { Button, SourceCard, ConfidenceIndicator, MessageBubble, Citation } from "./relay-ui";
```

## 使用例

```jsx
<MessageBubble
  role="assistant"
  footer={<ConfidenceIndicator score={0.92} compact />}
>
  入社から6か月で10日付与されます<Citation n={1} />。
</MessageBubble>

<SourceCard
  index={1}
  fileType="PDF"
  title="就業規則_2024年度改定版.pdf"
  snippet="雇入れの日から6箇月間継続勤務し、全労働日の8割以上出勤したときは、10労働日の年次有給休暇を与える。"
  relevance={0.94}
  meta="p.3 · 第15条"
  onOpen={() => openSource(1)}
/>
```

## コンポーネント一覧

**基本** — `Button` / `IconButton` / `TextField` / `TextArea` / `SearchField` / `Tag` / `StatusBadge` / `CountBadge`

**チャット / RAG** — `MessageBubble` / `Avatar` / `Citation` / `CitationChip` / `SourceCard` / `ConfidenceIndicator` / `GroundingWarning` / `StreamingText` / `TypingDots` / `Spinner`

**ドキュメント** — `DocumentRow` / `DocumentList` / `UploadDropzone` / `IngestProgress` / `ProcessingStatus`

**検索** — `SearchBar` / `FilterButton` / `FilterChip` / `SearchResultCard`

## トークン

`tokens.js` が単一の真実です（`colors` / `font` / `space` / `radius` / `shadow` / `fileTypeStyle`）。
配色やフォントの変更はここを編集すると全コンポーネントへ波及します。

## メモ

- アニメーション（点滅カーソル等）の `@keyframes` は `StreamingText` / `TypingDots` / `Spinner` が初回マウント時に自動注入します（`ensureKeyframes()`）。
- TypeScript（.tsx）版、Tailwind 版、Storybook 設定への変換も可能です。
